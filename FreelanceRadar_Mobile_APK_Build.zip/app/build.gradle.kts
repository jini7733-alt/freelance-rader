plugins {
    id("com.android.application")
}

android {
    namespace = "com.freelanceradar.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.freelanceradar.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 4
        versionName = "1.4-okky"
    }
}
