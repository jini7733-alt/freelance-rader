프리랜서 레이더 Android 앱 프로젝트

1. Android Studio에서 이 폴더(FreelanceRadarAndroid)를 엽니다.
2. Gradle Sync가 끝나면 상단 메뉴 Build > Build App Bundle(s) / APK(s) > Build APK(s)를 누릅니다.
3. 생성 위치:
   app/build/outputs/apk/debug/app-debug.apk
4. 휴대폰으로 APK를 옮겨 설치합니다.

앱 특징
- 원본 freelance-radar.html을 앱 내부에 포함했습니다.
- JavaScript / localStorage 데이터 저장을 지원합니다.
- 네이버, 구글, 공고 원문 등 외부 링크는 기본 브라우저로 엽니다.
- 인터넷 검색 링크 사용을 위해 INTERNET 권한만 사용합니다.

패키지명: com.freelanceradar.app
앱 이름: 프리랜서 레이더
버전: 1.0
